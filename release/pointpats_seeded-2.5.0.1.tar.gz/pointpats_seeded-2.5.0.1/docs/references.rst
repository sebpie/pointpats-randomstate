.. reference for the docs

References
==========

.. bibliography:: _static/references.bib
   :cited:
